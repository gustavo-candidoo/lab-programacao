let alfabeto = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]

function criptografar(){

    let palavra = document.getElementById("str").value.toLowerCase()
    let deslocamento = parseFloat(document.getElementById("des").value) + 1
    let input_e = document.getElementById("Entrada")
    let input_s = document.getElementById("Saida")

    let cripto = ""

    for(let i = 0; i < palavra.length; i++){
        if(palavra.charAt(i) == " "){
            cripto += " "
            continue
        }

        for(let j = 0; j < alfabeto.length; j++){
            if(alfabeto[j] == palavra.charAt(i)){
                cripto += alfabeto[(j + deslocamento) % alfabeto.length]
                break
            }
        }
    }
    input_e.value = palavra
    input_s.value = cripto
}

function descriptografar(){

    let palavra = document.getElementById("str2").value.toLowerCase()
    let deslocamento = parseFloat(document.getElementById("des2").value) + 1
    let input_e = document.getElementById("Entrada1")
    let input_s = document.getElementById("Saida1")

    let cripto = ""

    for(let i = 0; i < palavra.length; i++){
        if(palavra.charAt(i) == " "){
            cripto += " "
            continue
        }

        for(let j = 0; j < alfabeto.length; j++){
            if(alfabeto[j] == palavra.charAt(i)){
                const k = (j - deslocamento) % alfabeto.length;
                if (k < 0) {
                    cripto += alfabeto[k + alfabeto.length]
                } else {
                    cripto += alfabeto[k]
                }
                break
            }
        }
    }
    input_e.value = palavra
    input_s.value = cripto
}