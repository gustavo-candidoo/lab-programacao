function calcular () {
    let duracao = document.getElementById("duracao").value
    let hora = Math.floor(duracao / 60)
    let minuto = duracao % 60
    
    document.getElementById("mensagem").innerHTML = hora+":"+minuto
}