function calcular() {
    let msg = document.getElementById("mensagem")
    let msg2 = document.getElementById("mensagem2")
    let valor = document.getElementById("preco").value 
    valor = parseInt(valor)

    let entrada = 50/100 * valor
    let parcela = entrada / 12
    
    msg.innerHTML = "R$"+entrada
    msg2.innerHTML = "R$"+parcela.toFixed(2)
}