function teste(){
    valor = document.getElementsByName("teste").value
    console.log(teste)
}