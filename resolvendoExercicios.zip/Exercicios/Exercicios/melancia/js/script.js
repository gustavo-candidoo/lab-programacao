let frm = document.querySelector("form")
let pre = document.querySelector("pre")

/* evento quando o usuário clicar no botão apostar */
frm.addEventListener("submit", (e) => {
    e.preventDefault()

    let nome = frm.inNome.value
    let peso = Number(frm.inPeso.value)
    

    if(verificarPeso(peso)) {
        alert("Esse peso já está registrado")
        frm.inPeso.focus()
        return 
    }

    /* verifica se há algo armazenado */
    if(localStorage.getItem("listaNome") == null){
        localStorage.setItem("listaNome", nome)
        localStorage.setItem("listaPeso", peso)
    }
    else{
        let listaNome = localStorage.getItem("listaNome") + ";" + nome
        let listaPeso = localStorage.getItem("listaPeso") + ";" + peso
        localStorage.setItem("listaNome", listaNome)
        localStorage.setItem("listaPeso", listaPeso)
    }

    mostrarAposta()
    frm.reset()
    frm.inNome.focus()
})

/* função para verificar se o peso já foi armazenado */
function verificarPeso(peso) {
    let listaPeso = localStorage.getItem("listaPeso")
    let achou = false
    if(listaPeso != null){
        listaPeso = listaPeso.split(";")
        for(let i = 0; i < listaPeso.length; i++){
            if(listaPeso[i] == peso) {
                achou == true
            }
        }
    } 
    return achou 
}

/* função para exibir as apostas */
function mostrarAposta(){
    let listaNome = localStorage.getItem("listaNome").split(";")
    let listaPeso = localStorage.getItem("listaPeso").split(";") 
    let aux = ""
    for(let i = 0; i < listaNome.length; i++){
        aux += listaNome[i] + " --- " + listaPeso[i] + "g\n" 
    }

    pre.innerText = aux
}

/* evento para exibir as apostas quando o browser abrir a aplicação */
window.addEventListener("load", mostrarAposta())

frm.btLimpar.addEventListener("click", () => {
    if(confirm("Deseje apagar as apostas?")){
        localStorage.removeItem("listaNome")
        localStorage.removeItem("listaPeso")
        mostrarAposta()
    }
})